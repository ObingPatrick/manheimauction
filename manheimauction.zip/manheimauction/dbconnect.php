<?php
$con = mysqli_connect("localhost", "root", "", "testdb") or die("Error " . mysqli_error($con));
?>