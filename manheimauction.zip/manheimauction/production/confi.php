<?php
$dbhost = "localhost";
$dbuname = "root";
$dbpword = "";
$dbname = "testdb";

$conn = new mysqli($dbhost,$dbuname,$dbpword,$dbname) or
die("cannot to the server or database");

?>