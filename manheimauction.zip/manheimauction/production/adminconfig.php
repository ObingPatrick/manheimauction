<?php
$dbhost = "localhost";
$dbuname = "root";
$dbpword = "";
$dbname = "dbform";

$conn = new mysqli($dbhost,$dbuname,$dbpword,$dbname) or
die("cannot to the server or database");

?>