<?php 

session_start();
if(!isset($_SESSION['usr_id'])){
	header("location:indexform.php"); 	
}

?>
<!DOCTYPE HTML>
<head>
<title>Manheim | Auction</title>
<meta charset="utf-8">
<!-- Google Fonts -->
<link href='http://fonts.googleapis.com/css?family=Parisienne' rel='stylesheet' type='text/css'>
<!-- CSS Files -->
<link rel="stylesheet" type="text/css" media="screen" href="css/style.css">
<link rel="stylesheet" type="text/css" media="screen" href="menu/css/simple_menu.css">
<link rel="stylesheet" href="css/nivo-slider.css" type="text/css" media="screen">
<!-- Contact Form -->
<link href="contact-form/css/style.css" media="screen" rel="stylesheet" type="text/css">
<link href="contact-form/css/uniform.css" media="screen" rel="stylesheet" type="text/css">
</head>
<body>
<div class="header">
  <div id="site_title"><a href="index.php"><img src="img/logo1.jpg" width="200px" alt=""></a></div>
  <!-- Main Menu -->
  <ol id="menu">
    <li class="active_menu_item"><a href="index.php">Home</a>
      <!-- sub menu -->
    </li>
    </li>
    <!-- END sub menu -->
    <li><a href="stock.php">Stock</a></li>
    <!-- END sub menu -->
    <li><a href="contact.php">Contact</a></li>
	<li><a href="logout.php">Logout</a></li>
  </ol>
</div>
<!-- END header -->
<div id="container">
  <h1>Full Width Page</h1>
  <div class="one-half">
    <div class="heading_bg">
      <h2>Contact</h2>
    </div>
    <p><strong>Professional Studios</strong><br>
      NOVA<br>
      <br>
      Tel:  0333 444 0158<br>
      mail: manheim@mail.com</p>
    <iframe width="465" height="350" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="http://maps.google.no/maps?f=q&amp;source=s_q&amp;hl=no&amp;geocode=&amp;q=Hafstadvegen+35,+F%C3%B8rde&amp;aq=0&amp;oq=hafstadvegen+35&amp;sll=61.143235,9.09668&amp;sspn=17.454113,57.084961&amp;ie=UTF8&amp;hq=&amp;hnear=Hafstadvegen+35,+6800+F%C3%B8rde,+Sogn+og+Fjordane&amp;t=m&amp;z=14&amp;iwloc=A&amp;ll=61.450253,5.859145&amp;output=embed"></iframe>
    <br>
    <small><a href="#" style="color:#0000FF;text-align:left">Enlarge Map</a></small> </div>
 
  <div style="clear:both; height: 40px"></div>
</div>
<!-- close container -->
<div id="footer">
  <!-- First Column -->
  <div class="one-fourth">
    <h3>Useful Links</h3>
    <ul class="footer_links">
      <li><a href="#">Lorem Ipsum</a></li>
      <li><a href="#">Ellem Ciet</a></li>
      <li><a href="#">Currivitas</a></li>
      <li><a href="#">Salim Aritu</a></li>
    </ul>
  </div>
  <!-- Second Column -->
  <div class="one-fourth">
    <h3>Terms</h3>
    <ul class="footer_links">
      <li><a href="#">Manheim Auction Vehicles</a></li>
    </ul>
  </div>
  <!-- Third Column -->
  <div class="one-fourth">
    <h3>Information</h3>
    
    <div id="social_icons"><br>
      Photos © <a href="#">Manheim Auction Vehicles</a> </div>
  </div>
  <!-- Fourth Column -->
  <div class="one-fourth last">
    <h3>Socialize</h3>
    <img src="img/icon_fb.png" alt=""> <img src="img/icon_twitter.png" alt=""> <img src="img/icon_in.png" alt=""> </div>
  <div style="clear:both"></div>
</div>
<!-- END footer -->
</body>
</html>