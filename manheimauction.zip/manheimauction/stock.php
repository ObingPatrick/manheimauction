<?php 

session_start();
if(!isset($_SESSION['usr_id'])){
	header("location:indexform.php"); 	
}

?>
<!DOCTYPE HTML>
<head>
<title>Manheim | Auction</title>
<meta charset="utf-8">
<!-- Google Fonts -->
<link href='http://fonts.googleapis.com/css?family=Parisienne' rel='stylesheet' type='text/css'>
<!-- CSS Files -->
<link rel="stylesheet" type="text/css" media="screen" href="css/style.css">
<link rel="stylesheet" type="text/css" media="screen" href="menu/css/simple_menu.css">
<link rel="stylesheet" href="css/nivo-slider.css" type="text/css" media="screen">
<!-- JS Files -->
<script src="js/jquery.min.js"></script>
<script src="js/custom.js"></script>
<script src="js/slides/slides.min.jquery.js"></script>
<script src="js/cycle-slider/cycle.js"></script>
<script src="js/nivo-slider/jquery.nivo.slider.js"></script>
<script src="js/tabify/jquery.tabify.js"></script>
<script src="js/prettyPhoto/jquery.prettyPhoto.js"></script>
<script src="js/twitter/jquery.tweet.js"></script>
<script src="js/scrolltop/scrolltopcontrol.js"></script>
<script src="js/portfolio/filterable.js"></script>
<script src="js/modernizr/modernizr-2.0.3.js"></script>
<script src="js/easing/jquery.easing.1.3.js"></script>
<script src="js/kwicks/jquery.kwicks-1.5.1.pack.js"></script>
<script src="js/swfobject/swfobject.js"></script>
<!-- FancyBox -->
<link rel="stylesheet" type="text/css" href="js/fancybox/jquery.fancybox.css" media="all">
<script src="js/fancybox/jquery.fancybox-1.2.1.js"></script>
</head>
<body>
<div class="header">
  <div id="site_title"><a href="index.php"><img src="img/logo1.jpg" width="200px" alt=""></a></div>
  <!-- Main Menu -->
  <ol id="menu">
    <li class="active_menu_item"><a href="index.php">Home</a>
      <!-- sub menu -->
    </li>
    <!-- END sub menu -->
    <li><a href="stock.php">Stock</a></li>
    <!-- END sub menu -->
    <li><a href="contact.php">Contact</a></li>
	<li><a href="logout.php">Logout</a></li>
  </ol>
</div>
<!-- END header -->
<div id="container">
  <h1>Customer Side</h1>
  <div class="one-half">
    <div class="heading_bg">
      <h2>Tables</h2>
    </div>
    <table border="0">
     
    </table>

  </div>
  
  <?php
	include "config.php";
	
	if(ISSET($_GET['did'])){
	$id = $_GET['did'];
	mysqli_query($conn,"EDIT from user WHERE `id`='$id'");
	header("Location:stock.php?SIDEID=2");
	}
	
	$sql=mysqli_query($conn,"Select * from user");
	if(mysqli_num_rows($sql) >0){
		
		echo "<table id=datatable class=table>
			<thead>
			<tr>
				<td><b>ID</b></td>
				<td><b>Firstname</b></td>
				<td><b>Lastname</b></td>
				<td><b>Phone</b></td>
				<td><b>Address</b></td>
				<td><b>Car</b></td>
				<td><b>Price</b></td>
				<td><b>Messages</b></td>
				</tr>
			</thead>	
				";
				while($r=mysqli_fetch_object($sql)){
					echo"<tbody>";
					echo"<tr>";
					echo
				"<td>".$r->id."</td>
				<td>".$r->fname."</td>
				<td>".$r->lname."</td>
				<td>".$r->phone."</td>
				<td>".$r->address."</td>
				<td>".$r->car."</td>
				<td>".$r->price."</td>
				<td>".$r->message."</td>
				<TD><a href =?did=$r->id&SIDEID=3> <span class=glyphicon></span></a></TD>";

				
				echo "</tr>";
			
				}
				echo "</tbody>";
				echo "</TABLE>";
	}
?>          

<!-- close container -->
<div id="footer">
  <!-- First Column -->
  <div class="one-fourth">
    <h3>Useful Links</h3>
    <ul class="footer_links">
      <li><a href="#"></a></li>
      <li><a href="#">Toyota</a></li>
      <li><a href="#">Nissan</a></li>
      <li><a href="#">Mazda</a></li>
      <li><a href="#">Mitsubishi</a></li>
      <li><a href="#">Honda Civic</a></li>
    </ul>
  </div>
  <!-- Second Column -->
  <div class="one-fourth">
    <h3>Terms</h3>
    <ul class="footer_links">
      <li><a href="#">Manheim Auction Vehicles</a></li>
    </ul>
  </div>
  <!-- Third Column -->
  <div class="one-fourth">
    <h3>Information</h3>
    <div id="social_icons"> Theme by <a href="http://www.csstemplateheaven.com">CssTemplateHeaven</a><br>
      Photos © <a href="http://dieterschneider.net">Dieter Schneider</a> </div>
  </div>
  <!-- Fourth Column -->
  <div class="one-fourth last">
    <h3>Socialize</h3>
    <img src="img/icon_fb.png" alt=""> <img src="img/icon_twitter.png" alt=""> <img src="img/icon_in.png" alt=""> </div>
  <div style="clear:both"></div>
</div>
<!-- END footer -->
</body>
</html>