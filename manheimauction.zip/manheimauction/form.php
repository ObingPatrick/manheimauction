<?php 

session_start();
if(!isset($_SESSION['usr_id'])){
	header("location:indexform.php"); 	
}

?>
<?php
error_reporting(0);
include("formconnect.php");
$note=$_REQUEST['note'];
?>
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
    <title>Manheim | Auction</title>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <link rel="stylesheet" type="text/css" href="css1/style.css" />
</head>
<style>
a:visited {
    color:white;
}

</style>
<body>

<div id="page-wrap">
    <?PHP if($note=='success')
    {
    echo "<div class=\"success\">Form successfully submitted!</div>";
    }
?>
  <div class="row">
        <div class="col-md-4 col-md-offset-4 text-center">    
        <H2>Do you want to view? <a href="stock.php">Click me!</a></H2>
        </div>
    </div>
    <div id="contact-area">

            <form method="post" action="user_form.php">
			<h2>Bidders Details</h2><br><br><br>
		
			<label for="fname">First Name*</label>
            <input type="text" required autocomplete="off" name="fname" id="fname" />
			
			<label for="lname">Last Name*</label>
            <input type="text" required autocomplete="off" name="lname" id="lname" />
			
			<label for="phone">Phone*</label>
            <input type="text" required autocomplete="off" name="phone" id="phone" />
			
			<label for="address">Complete Address*</label>
            <input type="text" required autocomplete="off" name="address" id="address" />
	
			<label for="car" >Type of Car*</label>
			<SELECT NAME="car" required autocomplete="off">
			<OPTION VALUE="" Selected >- Select Auction Car -</OPTION>
			<OPTION VALUE="toyota86">Toyota86 ($24,930)</OPTION>
			<OPTION VALUE="Nissan GT-R">Nissan GT-R ($101,770)</OPTION>
			<OPTION VALUE="Mazda CX-5">Mazda CX-5 ($21,795)</OPTION>
			<OPTION VALUE="Mitsubishi Mirage">Mitsubishi Mirage ($20,224)</OPTION>
			<OPTION VALUE="Honda Civic">Honda Civic ($200,199)</OPTION>
			</SELECT><br><br>
			
			<label for="price">New Bidding Prices</label>
			<input type="price" name="price" required autocomplete="off">
	
            <label for="message">Message*</label><br />
            <textarea name="message" rows="20" cols="20" required autocomplete="off" id="message"></textarea><br><BR>


            <input type="submit" name="submit" value="Submit" class="submit-button" />
        </form>

        <div style="clear: both;"></div>
    </div>

</div>

</body>
</html>