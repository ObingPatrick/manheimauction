<?php
include("formconnect.php");

$fname=$_REQUEST['fname'];
$lname=$_REQUEST['lname'];
$phone=$_REQUEST['phone'];
$address=$_REQUEST['address'];
$car=$_REQUEST['car'];
$price=$_REQUEST['price'];
$message=$_REQUEST['message'];

$query=mysqli_query($db_connect, "INSERT INTO user(fname,lname,phone,address,car,price,message) VALUES('$fname','$lname','$phone','$address','$car','$price','$message')") or die(mysqli_error($db_connect));

mysqli_close($db_connect);

header("location:form.php?note=success");
?>