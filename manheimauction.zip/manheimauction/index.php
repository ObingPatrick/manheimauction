<?php 

session_start();
if(!isset($_SESSION['usr_id'])){
	header("location:indexform.php"); 	
}

?>
<!DOCTYPE HTML>
<head>
<title>Manheim | Auction</title>
<meta charset="utf-8">
<!-- Google Fonts -->
<link href='http://fonts.googleapis.com/css?family=Parisienne' rel='stylesheet' type='text/css'>
<!-- CSS Files -->
<link rel="stylesheet" type="text/css" media="screen" href="css/style.css">
<link rel="stylesheet" type="text/css" media="screen" href="menu/css/simple_menu.css">
<!-- Contact Form -->
<link href="contact-form/css/style.css" media="screen" rel="stylesheet" type="text/css">
<link href="contact-form/css/uniform.css" media="screen" rel="stylesheet" type="text/css">
<!-- JS Files -->
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.5.2/jquery.min.js"></script>
<script src="js/jquery.tools.min.js"></script>
<script>
$(function () {
    $("#prod_nav ul").tabs("#panes > div", {
        effect: 'fade',
        fadeOutSpeed: 400
    });
});
</script>
<script>
$(document).ready(function () {
    $(".pane-list li").click(function () {
        window.location = $(this).find("a").attr("href");
        return false;
    });
});
</script>
</head>
<body>
<div class="header">
  <div id="site_title"><a href="index.php"><img src="img/logo1.jpg" width="200px" alt=""></a></div>
  <!-- Main Menu -->
  <ol id="menu">
    <li class="active_menu_item"><a href="index.php">Home</a>
      <!-- sub menu -->
      
    <!-- END sub menu -->
    <li><a href="stock.php">Stock</a></li>
  
    <!-- END sub menu -->
    <li><a href="contact.php">Contact</a></li>
    <li><a href="logout.php">Logout</a></li>
	
  </ol>
</div>
<!-- END header -->
<div id="container">
  <!-- tab panes -->
  <div id="prod_wrapper">
    <div id="panes">
      <div> <img src="img/demo/car1.jpg" width="465" height="300" alt="">
        <h2>Toyota 86</h2>
        <p>The 86 is a series of sports cars jointly developed by Toyota and Subaru and solely manufactured by Subaru. It features a boxer engine, front engine, rear wheel drive drivetrain and 2+2 seating. ... Subaru BRZ worldwide; Scion FR-S in the US and Canada.</p>
        <p style="text-align:right; margin-right: 16px"><a href="form.php" class="button">Bid Now</a></p>
      </div>
      <div> <img src="img/demo/car2.jpg" width="465" height="300" alt="">
        <h2>Nissan GT-R</h2>
        <p>The Nissan Skyline GT-R is a Japanese sports car based on the Nissan Skyline range.</p>
        <p style="text-align:right; margin-right: 16px"><a href="form.php" class="button">Bid Now</a></p>
      </div>
      <div> <img src="img/demo/car3.jpg"  width="465" height="300" alt="">
        <h2>Mazda CX-5</h2>
        <p>The Mazda CX-5 is a compact crossover produced by Mazda starting in 2012 for the 2013 model year lineup. It is Mazda's first car featuring the new KODO – Soul of Motion Design language first shown in the Shinari concept vehicle in May 2011. It shares a platform with Mazda3 and Mazda6.</p>
        <p style="text-align:right; margin-right: 16px"><a href="form.php" class="button">Bid Now</a></p>
      </div>
      <div> <img src="img/demo/car4.jpg" width="465" height="300" alt="">
        <h2>Mitsubishi Mirage</h2>
        <p>The Mitsubishi Mirage is a range of cars produced by the Japanese manufacturer Mitsubishi from 1978 to 2003 and again since 2012.</p>
        <p style="text-align:right; margin-right: 16px"><a href="form.php" class="button">Bid Now</a></p>
      </div>
      <div> <img src="img/demo/car5.jpg"  width="465" height="300" alt="">
        <h2>Honda Civic</h2>
        <p>The Honda Civic Si is a sport compact trim of Civic by Honda. The Si (Sport Injected) trim was introduced for the third generation of Honda Civics in both Japan and North America.</p>
        <p style="text-align:right; margin-right: 16px"><a href="form.php" class="button">Bid Now</a></p>
      </div>
	  <div> <img src="img/demo/car6.jpg"  width="465" height="300" alt="">
        <h2>Suzuki New Vitara</h2>
        <p>The Suzuki Vitara is a compact SUV produced by Suzuki since 1988. The second and third generation models were known as the Suzuki Grand Vitara, with the fourth and current series eschewing this prefix. In Japan, all generations have used the name Suzuki Escudo. The name is derived from the "escudo", the monetary unit of Portugal until the Euro was adopted.</p>
        <p style="text-align:right; margin-right: 16px"><a href="form.php" class="button">Bid Now</a></p>
      </div>
    </div>
    <!-- END tab panes -->
    <br clear="all">
    <!-- navigator --> 
    <div id="prod_nav">
      <ul>
        <li><a href="#1"><img src="img/demo/car1.jpg" width="160" alt=""><strong>Toyota 86</strong> $ 24,930</a></li>
        <li><a href="#2"><img src="img/demo/car2.jpg" width="160" alt=""><strong>Nissan GT-R</strong> $ 101,770</a></li>
        <li><a href="#3"><img src="img/demo/car3.jpg" width="160" alt=""><strong>Mazda CX-5</strong> $ 21,795</a></li>
        <li><a href="#4"><img src="img/demo/car4.jpg" width="160" alt=""><strong>Mitsubishi Mirage</strong> $ 20,224</a></li>
        <li><a href="#5"><img src="img/demo/car5.jpg" width="160" alt=""><strong>Honda Civic</strong> $ 200,199</a></li>
      </ul>
      </ul>
    </div>
    <!-- END navigator -->
  </div>
  <!-- END prod wrapper -->
  <div style="clear:both"></div>
  <div class="one-third">
    <h2>Business Solutions</h2>
    <p>With more than 100 years’ experience under our belt, we’ve already transformed and improved every stage of the vehicle lifecycle, including sales. </p>
    <p style="text-align:right; margin-right: 15px"></p>
  </div>
  <div class="one-third">
    <h2>Become a Partner</h2>
    <p>The DHBW Mannheim operates like a business partnership. During the scientific-theoretical part of their studies, the students collaborate closely with their fellow students at the DHBW, as well as while they are completing the practical part with their partner company.</p>
    <p style="text-align:right; margin-right: 15px"></p>
  </div>
  <div class="one-third last">
    <h2>Latest News</h2>
    <p>Nulla hendrerit commodo tortor, vitae elementum magna convallis nec. Nam tempor nibh a purus aliquam et adipiscing elit gravida.</p>
    <p style="text-align:right; margin-right: 15px"></p>
  </div>
  <div style="clear:both"></div>
  <div class="box_highlight" style="margin-top:40px">
    <h2 style="text-align:center">Others information for Manheim Auction</h2>
  </div>
  <div class="one-half">
    <div class="heading_bg">
      <h2>About Us</h2>
    </div>
    <blockquote>Manheim was established in 1945 as a wholesale vehicle auction operation.</blockquote>
    <p style="text-align:right; margin-right: 16px; margin-bottom: 15px"><a href="#" class="button" style="font-size: 18px">Find out more</a></p>
    <div class="heading_bg">
      <h2>Video</h2>
    </div>
    <iframe src="http://player.vimeo.com/video/22884674?title=0&amp;byline=0&amp;portrait=0&amp;color=ffffff" width="465" height="262" frameborder="0" webkitAllowFullScreen mozallowfullscreen allowFullScreen></iframe>
  </div>

  <div style="clear:both; height: 40px"></div>
</div>
<!-- END container -->
<div id="footer">
  <!-- First Column -->
  <div class="one-fourth">
    <h3>Useful Links</h3>
    <ul class="footer_links">
      <li><a href="#"></a></li>
      <li><a href="http://www.toyota.com/">Toyota</a></li>
      <li><a href="https://www.nissanusa.com">Nissan</a></li>
      <li><a href="http://www.edmunds.com/mazda/">Mazda</a></li>
      <li><a href="http://www.mitsubishicars.com/">Mitsubishi</a></li>
      <li><a href="https://hondainamerica.com/">Honda Civic</a></li>
    </ul>
  </div>
  <!-- Second Column -->
  <div class="one-fourth">
    <h3>Terms</h3>
    <ul class="footer_links">
      <li><a href="#">Manheim Auction Vehicles</a></li>
    </ul>
  </div>
  <!-- Third Column -->
  <div class="one-fourth">
    <h3>Information</h3>
    
    <div id="social_icons"><br>
      Photos © <a href="#">Manheim Auction Vehicles</a> </div>
  </div>
  <!-- Fourth Column -->
  <div class="one-fourth last">
    <h3>Socialize</h3>
    <img src="img/icon_fb.png" alt=""> <img src="img/icon_twitter.png" alt=""> <img src="img/icon_in.png" alt=""> </div>
  <div style="clear:both"></div>
</div>
<!-- END footer -->
</body>
</html>